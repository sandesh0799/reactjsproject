module.exports={
    username:'@@@',
    password:'@@@',
    dbname:'@@@',
}