const mongoose=require('mongoose');
var newschema={
    name:{
        type:String,
        trim:true,
        required:true
    },
    price:{
        type:String,
        trim:true,
        required:true
    },
    quantity:{
        type:String,
        trim:true,
        required:true
    },
    description:{
        type:String,
        trim:true,
        required:true
    },
}
module.exports=Product=mongoose.model('produts',newschema)