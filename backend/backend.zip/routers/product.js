const express=require('express');
const router=express.Router();
const Product=require('./../models/product');
router.post('/saveProduct',(req,res)=>{
    let addProduct={
    name:req.body.name,
    price:req.body.price,
    quantity:req.body.quantity,
    description:req.body.description 
}
new Product(addProduct).save()
    .then(()=>{
        res.status("200").json({msg:"product Inserted Successfully!"});
    }).catch((err)=>{
        console.log(err);
    })
})

router.get('/viewProduct', function (req, res) {
    Product.find({})
    .then((response)=>{
        res.status("200").json(response)   
    }).catch((err)=>{
        console.log(err);
    })
})

router.get('/deleteProduct/:id',(req,res)=>{
    Product.deleteOne({_id:req.params.id})
    .then((response)=>{
        res.status("200").json({msg:"Data Deleted Successfully!"})
    })
    .catch((err)=>{
        console.log(err);
    })
})

router.get('/editProduct/:id',(req,res)=>{
    Product.findOne({_id:req.params.id})
    .then((response)=>{
        res.status("200").json(response) 
    })
    .catch(err=>{
        console.log(err);
    })
})

router.post('/updateProduct',(req,res)=>{
    Product.findOne({_id:req.body.id})
    .then((data)=>{
        data.name=req.body.name;
        data.price=req.body.price;
        data.quantity=req.body.quantity;
        data.description=req.body.description;
        data.save()
        .then((result)=>{
            res.status("200").json(result);
        }).catch((err)=>{
            console.log(err);
        })

    })
    .catch((err)=>{
        console.log(err);
    })
})
module.exports=router;